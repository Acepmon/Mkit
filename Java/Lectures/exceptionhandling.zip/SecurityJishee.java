package ExceptionJishee;

public class SecurityJishee extends SecurityManager {

   @Override
   public void checkExit(int status) {
      throw new SecurityException("Not allowed.");
   }

   public static void main(String[] args) {


     
      System.setProperty("java.security.policy", "file:/C:\\Users\\adik\\Documents\\NetBeansProjectsjava.policy");

    
      SecurityJishee sm = new SecurityJishee();

      
      System.setSecurityManager(sm);

      sm.checkExit(5);

      
      System.out.println("Allowed!");
   }
}
