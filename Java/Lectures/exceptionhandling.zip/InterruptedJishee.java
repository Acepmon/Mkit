package ExceptionJishee;
import java.util.concurrent.TimeUnit;

public class InterruptedJishee extends Thread {
	public InterruptedJishee() {
		super();
		System.out.println("An instance of the " + InterruptedJishee.class + " class was created!");
	}
	
	@Override
	public void run() {
		try {
			/* Sleep for some seconds. */
			TimeUnit.SECONDS.sleep(10);
		}
		catch(InterruptedException ex) {
			System.err.println("An InterruptedException was caught: " + ex.getMessage());
		}
	}
}
