package ExceptionJishee;
public class ArifmeticJishee {

   public static void main(String args[])
   {
      try{
         int num1=30, num2=0;
         int output=num1/num2;
         System.out.println ("Үр дүн = " +output);
      }
      catch(ArithmeticException e){
         System.out.println ("Тоог тэгд хувааж болохгүй");
      }
   }
}

