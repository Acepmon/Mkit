package ExceptionJishee;

public class NegativeArrayJishee {
    public static void main(String args[]){
        try{
            int x[] = new int[-1];
        }catch(NegativeArraySizeException e){
            System.out.println("massivin index hasah utgatai baij bolohgui");
        }
        
    }
}
