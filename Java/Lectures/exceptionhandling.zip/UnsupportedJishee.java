package ExceptionJishee;
    import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
public class UnsupportedJishee {

	private final static int TOTAL_ELEMS = 10;
	private final static Random random = new Random();
	
	public static void main(String[] args) {
		Collection integers = new HashSet(TOTAL_ELEMS);
		
		
		for(int i = 0; i < TOTAL_ELEMS; ++i)
			integers.add(random.nextInt());
		
		
		Collection unmodifiableCollection = Collections.unmodifiableCollection(integers);
		
		
		unmodifiableCollection.add(random.nextInt());
	}
}

