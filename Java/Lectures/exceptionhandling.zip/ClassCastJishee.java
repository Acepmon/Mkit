package ExceptionJishee;

public class ClassCastJishee {
    public static void main(String args[]){
        try {
            Object x = new Integer(0);
        
        System.out.println((String)x); }
        
            catch(ClassCastException e){
                System.out.println("Class cast exception uuslee");
                }
        
    }
}
