package ExceptionJishee;
public class ArrayStoreJishee {
    public static void main(String args[]){
        try{
            Object[] x = new Integer[4];
            x[0] = 4.4;
                    }
            catch(ArrayStoreException e){
                    System.out.println("ArrayStoreException uuslee");
                    }
        
    }
}
