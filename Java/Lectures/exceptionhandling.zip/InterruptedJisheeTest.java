package ExceptionJishee;

public class InterruptedJisheeTest {
	public static void main(String[] args) throws InterruptedException {
	
		Thread thread = new InterruptedJishee();
		
	
		thread.start();

		thread.interrupt();
	
		thread.join();
	}
}
