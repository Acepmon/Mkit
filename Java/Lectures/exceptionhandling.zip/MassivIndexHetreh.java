package ExceptionJishee;
    
public class MassivIndexHetreh {
   public static void main(String args[]){
      try{
         int a[] = new int[2];
         System.out.println("3 дахь элэментд хандах :" + a[3]);
      }catch(ArrayIndexOutOfBoundsException e){
         System.out.println("Алдаа :" + e);
      }
      System.out.println("Индекс хальсан");
   }
}

