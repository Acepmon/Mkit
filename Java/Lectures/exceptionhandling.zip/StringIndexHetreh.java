package ExceptionJishee;
public class StringIndexHetreh {
        public static void main(String args[]){
            try {
                String str = "adgdsdefe";
                System.out.println(str.length());
                
                char c = str.charAt(34);
            }
            catch (StringIndexOutOfBoundsException e){
                System.out.println("String index haliv");
                
            }
        }
}
