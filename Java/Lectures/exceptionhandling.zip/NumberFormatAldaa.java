package ExceptionJishee;

public class NumberFormatAldaa {
    public static void main(String args[]){
        
        try {
            int num = Integer.parseInt("ABC");
            System.out.println(num);
        }
                catch (NumberFormatException nf){
                        System.out.println("Number Format Exception garlaa");
        }
    }
}
